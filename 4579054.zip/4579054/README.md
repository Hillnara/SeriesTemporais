# SeriesTemporais
UEPB
